export function products(defStore=[],action){
    switch(action.type){
        case 'ADD_NEW_PRODUCT':
                 console.log('Within products Reducer..'+ action.type);
                 return defStore; // return a new store !
         default:
                 return defStore;//
    }
}