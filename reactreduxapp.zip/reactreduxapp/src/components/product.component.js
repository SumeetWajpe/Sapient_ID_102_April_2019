import React from 'react';

export class Product extends React.Component{
    render(){
        return <h1>  Product Component !</h1>
    }
}