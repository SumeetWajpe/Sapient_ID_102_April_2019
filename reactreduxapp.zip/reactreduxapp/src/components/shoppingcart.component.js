import React from 'react';

export class ShoppingCart extends React.Component{
    render(){
        console.log(this.props.allproducts);
        return <h1>  Shopping Cart !</h1>
    }
}