describe('setup/teardown',function(){
    var arr;
    beforeEach(function(){
        // Initialization !
        arr = [10,20,30];
        console.log('Within beforeEach !')
    });
    afterEach(function(){
        console.log('Within afterEach !');
    });
    beforeAll(function(){
        console.log('Within beforeAll !');
    });
    afterAll(function(){
        console.log('Within afterAll !');
    });
    it('use setup and tear down methods',function(){
            expect(arr).toContain(20);
    });
    it('length of the array',function(){
        expect(arr.length).toBe(3);
});
});