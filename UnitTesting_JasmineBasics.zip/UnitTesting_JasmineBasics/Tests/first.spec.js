xdescribe("A suite is just a function", function() {
    var a;  
    it("and so is a spec", function() {
      a = true;  
      expect(a).toBe(true);
    });
  });

  xdescribe('basic matchers',function(){
      xit('use of toBe ===',function(){
            expect(10).toBe('10');
      });

      xit('use of toEqual ===+object inspection',function(){
          //expect(60).toEqual(60);
          var o = {name:'Sapient'};
          expect(o).toEqual({name:'Sapient'})
      });

      xit('use of toMatch : regEx',function(){
          expect('Sapient is a Company').toMatch(/company/i);
      });

      xit('use of toBeDefined',function(){
          var obj = {};
          expect(obj.AnyDynamicProperty).not.toBeDefined();
      });

      it('use of toContain',function(){
          //var str = "Sapient is a Company";
          //expect(str).toContain('Company');
                    // OR
          var companies = ['Microsoft','Accenture'];
          expect(companies).toContain("Sapient")
      });
      function ThisThrowsAnError(){
          throw new TypeError('My Expection !')
      }
      xit('use of toThrowError',function(){
          expect(ThisThrowsAnError).toThrowError(TypeError);
      });
  });