import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import renderer from 'react-test-renderer';

import Enzyme,{shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('App counter component ',function(){
  it('starts with a count of 0',function(){
    // create an instance of App
    var wrapperInstance = shallow(<App />);
    var count = wrapperInstance.state().count;
    expect(count).toEqual(0);
  });

  it('can increment count on click of button',function(){
        // create an instance of App
        var wrapperInstance = shallow(<App />);
        var incrementBtn = wrapperInstance.find('button');
        incrementBtn.simulate('click');
        var pText = wrapperInstance.find('p').text();
        expect(pText).toEqual('Current Count : 1');

  });

  it('takes snapshot',function(){
        var tree = renderer.create(<App/>).toJSON();
        expect(tree).toMatchSnapshot();

  });
});