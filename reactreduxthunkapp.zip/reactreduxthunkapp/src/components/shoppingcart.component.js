import React from 'react';
import { Product } from './product.component';
import {Progress} from './progress.component';
import {Link} from 'react-router-dom';

export class ShoppingCart extends React.Component{
    constructor(props) {
        super(props);          
    }
  
   
    render(){
        var productsToBeCreated;
        if(this.props.allproducts.length == 0){
             productsToBeCreated =   <Progress />
        } else {
             productsToBeCreated = this.props.allproducts.map((p,i) =>
                <Product productdetails={p} key={p.id} pindex={i} {...this.props} />);            
        }
        return ( 
            <div className="container">
                <div>
                    <h1 className="jumbotron"> Welcome to online shopping ! </h1>
                </div>     
                
<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Online Shopping</Link>
    </div>
    <ul className="nav navbar-nav">
      <li><Link to="/">Home </Link></li>
      <li><Link to="/newproduct">Add a new Product  </Link></li>      
    </ul>
  </div>
</nav>    
                            <div className="row">
                                {productsToBeCreated}                               
                            </div>
                        </div>
                        );

              }
    }