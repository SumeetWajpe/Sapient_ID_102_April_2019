import React from "react";

export class NewProduct extends React.Component{
    
    handleaddnewproduct(){
        let aNewProduct = {
            id:this.refs.txtId.value,
            title:this.refs.txtName.value,
            ImageUrl:this.refs.txtImage.value
        };

        this.props.AddNewProduct(aNewProduct);
 
    }
    
    render(){
        return  <div className="container">
        <div className="jumbotron">
            <h1> New Product</h1>
        </div>
            <form className="form-horizontal">
        <div className="form-group">
            <label htmlFor="inputId" className="col-sm-2 control-label">Id:</label>
            <div className="col-sm-10">
                <input type="number" ref="txtId" className="form-control" id="inputId" placeholder="Id"/>
            </div>
            </div>
            <div className="form-group">
                <label htmlFor="inputName" className="col-sm-2 control-label">Name:</label>
                <div className="col-sm-10">
                    <input type="text" ref="txtName" className="form-control" id="inputName" placeholder="Name"/>
                </div>
                </div>
                <div className="form-group">
                         <label htmlFor="inputQuantity" className="col-sm-2 control-label">Quantity:</label>
                        <div className="col-sm-10">
                        <input type="number" className="form-control" id="inputQuantity" placeholder="Quantity"/>
                        </div>
                </div>
                <div className="form-group">
                         <label htmlFor="inputRating" className="col-sm-2 control-label">Rating:</label>
                        <div className="col-sm-10">
                        <input type="number" className="form-control" id="inputRating" placeholder="Rating"/>
                        </div>
                </div>
                <div className="form-group">
                         <label htmlFor="inputLikes" className="col-sm-2 control-label">Likes:</label>
                        <div className="col-sm-10">
                        <input type="number" className="form-control" id="inputLikes" placeholder="Likes"/>
                        </div>
                </div>
                <div className="form-group">
                         <label htmlFor="inputPrice" className="col-sm-2 control-label">Price:</label>
                        <div className="col-sm-10">
                        <input type="number" className="form-control" id="inputPrice" placeholder="Price"/>
                        </div>
                </div>
                <div className="form-group">
                         <label htmlFor="inputImage" className="col-sm-2 control-label">Image Url:</label>
                        <div className="col-sm-10">
                        <input type="text" ref="txtImage" className="form-control" id="inputImage" placeholder="Image"/>
                        </div>
                </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-10">
                            <button type="button" className="btn btn-success" onClick={this.handleaddnewproduct.bind(this)}>
                                    Add Product &nbsp;
                                    <span className="glyphicon glyphicon-plus-sign"></span>
                            </button>
                        </div>
                    </div>
            </form>
            </div>

    }
}