import axios from 'axios';

export function AddNewProduct(thenewproduct) {
    return {type:'ADD_NEW_PRODUCT',thenewproduct};
}

export function RemoveProduct(theId){
    return {type:'REMOVE_PRODUCT',theId}
}

export function IncrementLikes(theIndex){
    return {type:'INCREMENT_LIKES',theIndex}
}

export function AddUser(){
    return {type:'ADD_USER'}
}

export function FetchProducts(){
// make an ajax request !
var thePromise = axios.get('https://api.myjson.com/bins/rwxws');
return (dispatch)=>{
    thePromise.then(
        (response)=>{
            console.log('Dispatching FETCH_PRODUCTS')
            dispatch({type:'FETCH_PRODUCTS',response:response.data});// delaying the action dispacthing
        },
        (err)=>{}
    )
}
}