import React from 'react';
// export default function FunctionalComponent(props){
//     return <h1> Functional Component {props.msg} !</h1>
// }

// OR

var FunctionalComponent = (props)=> <h1> Functional Component {props.msg} !</h1>
export default FunctionalComponent;


// function Square(x){
//     return x * x;
// }

// var Square = function(x){
//     return x * x;
// }

// var Square = x=>{
//     return x * x;
// }

// /// OR

// var Square = x=> x * x;
