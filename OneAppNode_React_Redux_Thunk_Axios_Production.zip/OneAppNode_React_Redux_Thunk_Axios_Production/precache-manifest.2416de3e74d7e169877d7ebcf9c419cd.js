self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f34148d614470707b46ecd1a3d105715",
    "url": "/index.html"
  },
  {
    "revision": "c8a79683c6a3342acb26",
    "url": "/static/css/main.e42f04a2.chunk.css"
  },
  {
    "revision": "dbf2ebf02ae39a0a02fb",
    "url": "/static/js/2.085929db.chunk.js"
  },
  {
    "revision": "c8a79683c6a3342acb26",
    "url": "/static/js/main.846b3341.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);