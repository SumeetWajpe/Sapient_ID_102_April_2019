var express = require('express');
var app = express();
var mongodb = require('mongodb');
var bodyParser = require('body-parser');

var cors = require('cors'); // requiring cors !
var router = express.Router(); // Server side !

router.route('/products').get((req,res)=>{
        //  code to get data from mongodb !
        // connect to mongodb
        //use MongoClient -> pkg mongodb
        // get the records
        //pass the collection as json !
        let url = "mongodb://127.0.0.1:27017";
        let MongoClient = mongodb.MongoClient;
        MongoClient.connect(url,{useNewUrlParser:true},(err,db)=>{
                    if(err){
                        console.log(err);
                    }else{
                        let collection = db.db("SapientDB").collection("productlist");
                        //Select * from Productlist;

                        collection.find({}).toArray((err,result)=>{
                                if(result.length){
                                    res.json(result);// sending the json response
                                }
                        })
                    }
        }) ;
});
router.route('/products/new').post((req,res)=>{   
    let url = "mongodb://127.0.0.1:27017";
    let MongoClient = mongodb.MongoClient;
    MongoClient.connect(url,{useNewUrlParser:true},(err,db)=>{
                if(err){
                    console.log(err);
                }else{
                    let collection = db.db("SapientDB").collection("productlist");
                    //Select * from Productlist;

                   let newProduct = (req.body);
                    collection.insert(newProduct).then(
                        (success)=>{
                            console.log(success.insertedCount + " inserted !")
                            res.send("success");
                        }
                    )

                    
                }
    }) ;
});
router.route('/login').post((req,res)=>{ 
    let userCredentials = (req.body);
    if(userCredentials.uname === "admin" && userCredentials.upwd === "admin"){
        console.log('authenticated')
        res.send("authenticated");
    }    
});

app.use(cors()); // enabling cors for the entire app !
app.use(bodyParser.json());
app.use(express.static(__dirname + 'static'));
app.use('/',router);

app.get('/',(req,res)=>{
    res.sendFile("Index.html",{root:__dirname})
})

app.use((req,res)=>{
        res.statusCode = 404;
        res.send("<h1>Error ! </h1>")
});

app.listen(5000,()=>{
    console.log('Server running at port 5000 !')
})