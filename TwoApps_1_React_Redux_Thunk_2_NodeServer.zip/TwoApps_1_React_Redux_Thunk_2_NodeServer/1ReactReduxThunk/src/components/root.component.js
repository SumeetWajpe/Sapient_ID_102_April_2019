import React from 'react';
import { Route,Switch} from 'react-router-dom';
import { ShoppingCart } from './shoppingcart.component';
import { NewProduct } from './new.product';
import { Login } from './login.component';

export default class RootApp extends React.Component{
 
    render(){       
          return <div>
                        <Switch>
                        <Route exact path='/' render={(props)=><Login history={props.history} {...this.props}/>} />
                          <Route path='/cart' render={()=><ShoppingCart {...this.props}/>} />
                          <Route path='/newproduct' render={()=> <NewProduct {...this.props} />} />    
                        </Switch>
                    </div>
    }
  }

