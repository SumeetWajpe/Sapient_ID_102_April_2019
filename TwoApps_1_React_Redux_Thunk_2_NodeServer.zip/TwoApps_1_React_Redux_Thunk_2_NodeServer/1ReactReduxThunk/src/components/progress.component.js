import React, { Component } from 'react';
import './product.component.css';

export class Progress extends Component {
    
  render() {
    return (
      <div className="col-md-8 col-md-push-4">
          <img src="https://loading.io/spinners/rolling/lg.curve-bars-loading-indicator.gif" />
      </div>
    );
  }
}


