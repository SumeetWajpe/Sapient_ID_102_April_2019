export function users(defStore=[{isUserLoggedIn:false}],action){
   switch(action.type){
       case 'ADD_USER':
                console.log('Within users Reducer..'+ action.type);
                console.log(defStore);
                return defStore; // return a new store !
        case 'IS_USER_AUTHENTICATED':   
        console.log('IS_USER_AUTHENTICATED')             
                return [{isUserLoggedIn:true}]; // return a new store !
        default:
                return defStore;//
   }
}