export function products(defStore=[],action){
    switch(action.type){
        // case 'ADD_NEW_PRODUCT':                         
        //          return [...defStore,action.thenewproduct]
        case 'INCREMENT_LIKES':

            return [
                ...defStore.slice(0,action.theIndex),
                {...defStore[action.theIndex],likes:defStore[action.theIndex].likes + 1},
                ...defStore.slice(action.theIndex+1)
            ];

            case 'FETCH_PRODUCTS':
            return action.response;

            case 'ADD_NEW_PRODUCT_SUCCESS':
            return [...defStore,action.thenewproduct];
                        
        case 'REMOVE_PRODUCT':
              
                let theNewList = defStore.filter(p => p.id !== action.theId);
                return theNewList; // return a new store !                
              default:
                 return defStore;//
    }
}