import axios from 'axios';

export function AddNewProductLoading(thenewproduct) {
    var thePromise = axios.post('http://localhost:5000/products/new',thenewproduct,{
        headers: {
            'Content-Type': 'application/json'
        }
    });
return (dispatch)=>{
    thePromise.then(
        (response)=>{
            console.log('Dispatching AddNewProductSuccess')
            if(response ==="success")
                    dispatch({type:'ADD_NEW_PRODUCT_SUCCESS',thenewproduct});// delaying the action dispacthing
        },
        (err)=>{}
    )
}    
}

export function AuthenticateUser(theUser) {

    var thePromise = axios.post('http://localhost:5000/login',theUser,{
        headers: {
            'Content-Type': 'application/json'
        }
    });
return (dispatch)=>{
    thePromise.then(
        (response)=>{          
            if(response.data ==="authenticated")
                    dispatch({type:'IS_USER_AUTHENTICATED'});// delaying the action dispacthing
        },
        (err)=>{}
    )
}   

    
}

export function RemoveProduct(theId){
    return {type:'REMOVE_PRODUCT',theId}
}

export function IncrementLikes(theIndex){
    return {type:'INCREMENT_LIKES',theIndex}
}

export function AddUser(){
    return {type:'ADD_USER'}
}

export function FetchProducts(){
// make an ajax request !
var thePromise = axios.get('http://localhost:5000/products');
return (dispatch)=>{
    thePromise.then(
        (response)=>{
            console.log('Dispatching FETCH_PRODUCTS')
            dispatch({type:'FETCH_PRODUCTS',response:response.data});// delaying the action dispacthing
        },
        (err)=>{}
    )
}
}