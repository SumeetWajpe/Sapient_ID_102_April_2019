import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
          <h1> App using Create React App utility !</h1>
      </div>
    );
  }
}

export default App;
