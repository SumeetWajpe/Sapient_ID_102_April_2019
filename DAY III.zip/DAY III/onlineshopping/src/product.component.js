import React, { Component } from 'react';
import './product.component.css';

class Product extends Component {
    IncrementLikes(){

    }
  render() {
    return (
      <div className="col-md-4 product-box">
          <div className="container-fluid">
                <div className="row">
                    <div className="col-md-10">
                       <h2> {this.props.productdetails.title}</h2>
                    </div> 
                    <div className="col-md-2">
                    <button className="btn btn-danger" onClick={this.props.deleteitem.bind(this,this.props.productdetails.id)}>                                 
                                    <span className="glyphicon glyphicon-trash"></span>
                    </button>
                    </div>                 
                </div>
                <div className="row">
                <div className="col-md-7">
                        <img src={this.props.productdetails.ImageUrl} className="imgstyle img-thumbnail" />
                    </div>
                    <div className="col-md-5">
                        <p><strong>Id :</strong> {this.props.productdetails.id}</p> 
                        <p><strong>Rating :</strong> {this.props.productdetails.rating}</p> 
                        <p><strong>Quantity :</strong> {this.props.productdetails.quantity}</p> 
                        <p><strong>Price:</strong> {this.props.productdetails.price}</p> 
                </div>
                </div>
                <div className="row">
                        <div className="col-md-3 col-md-push-7">
                                <button className="btn btn-primary">
                                    {this.props.productdetails.likes}
                                    <span className="glyphicon glyphicon-thumbs-up"></span>
                                </button>
                        </div>
                </div>
          </div>
      </div>
    );
  }
}

export default Product;
